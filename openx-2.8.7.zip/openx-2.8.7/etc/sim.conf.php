;<?php exit; ?>
;*** DO NOT REMOVE THE LINE ABOVE ***
[simdb]
type = "mysql"
host = "localhost"
port = "3306"
username = ""
password = ""
name = ""
prefix = ""
apphost=""
[scenario]
startdate = "2000-01-01 00:00:00"
iterations = "1"
precis = "Test Simulation"
resetpriority=1
[request]
what = "zone:1"
target = ""
source = ""
withText = "false"
richMedia = "true"
ct0 = ""
loc = ""
referer = ""
maxrequests = "1"
[delivery]
cacheExpire = "0"
[logging]
adImpressions = "0"
[maintenance]
autoMaintenance = "0"