<?php

class plgContentFlowplayer {

	/**
	 * Video id
	 * @var integer
	 */
	protected $_video_id;

	/**
	 * Video width
	 * @var integer
	 */
	protected $_width;

	/**
	 * Video height
	 * @var integer
	 */
	protected $_height;

	/**
	 * Default constructor
	 * @param integer $video_id Video id
	 * @param integer $width Video width
	 * @param integer $height Video height
	 */
	public function __construct($video_id = null, $width = 425, $height = 300)
	{
		if ($video_id === null)
			$video_id = rand(1, 2);
		$this->_video_id = $video_id;
		$this->_width = intval($width);
		$this->_height = intval($height);
	}

	/**
	 * Load the video
	 *
	 * @return string HTML output
	 */
	public function load()
	{
		$name = 'flowplayer-700.flv';
		$output = '<html>' . PHP_EOL;
		$output .= '<head>' . PHP_EOL;
		$output .= '<script type="text/javascript" src="javascripts/jquery.min.js"></script>' . PHP_EOL;
		$output .= '<script type="text/javascript" src="javascripts/flowplayer-3.2.6.min.js"></script>' . PHP_EOL;
		$output .= '<script type="text/javascript" src="javascripts/flowplayer.playlist-3.0.8.min.js"></script>' . PHP_EOL;
		$output .= '</head>' . PHP_EOL;
		$output .= '<body>' . PHP_EOL;
		$output .= '<a ' . PHP_EOL;
		$output .= 'href="videos/video' . $this->_video_id . '.flv" ' . PHP_EOL;
		$output .= 'style="display: block; width:' . $this->_width . 'px; height: ' . $this->_height . 'px;"' . PHP_EOL;
		$output .= 'id="player">' . PHP_EOL;
		$output .= '<img src="thumbs/video' . $this->_video_id . '.jpg" />' . PHP_EOL;
		$output .= '</a>' . PHP_EOL;
		$output .= '<div id="playlist">' . PHP_EOL;
		$output .= '<a ' . PHP_EOL;
		$output .= 'href="videos/video' . $this->_video_id . '.flv" ' . PHP_EOL;
		$output .= 'style="display: block; width:' . $this->_width . 'px; height: ' . $this->_height . 'px;"' . PHP_EOL;
		$output .= 'id="player">' . PHP_EOL;
		$output .= '<img src="thumbs/video' . $this->_video_id . '.jpg" />' . PHP_EOL;
		$output .= '</a>' . PHP_EOL;
		$output .= '<a ' . PHP_EOL;
		$output .= 'href="videos/video1.flv" ' . PHP_EOL;
		$output .= 'style="display: block; width:' . $this->_width . 'px; height: ' . $this->_height . 'px;"' . PHP_EOL;
		$output .= 'id="player">' . PHP_EOL;
		$output .= '<img src="thumbs/video1.jpg" />' . PHP_EOL;
		$output .= '</a>' . PHP_EOL;
		$output .= '<a ' . PHP_EOL;
		$output .= 'href="videos/video2.flv" ' . PHP_EOL;
		$output .= 'style="display: block; width:' . $this->_width . 'px; height: ' . $this->_height . 'px;"' . PHP_EOL;
		$output .= 'id="player">' . PHP_EOL;
		$output .= '<img src="thumbs/video2.jpg" />' . PHP_EOL;
		$output .= '</a>' . PHP_EOL;
		$output .= '</div>' . PHP_EOL;
		$output .= '<script type="text/javascript">' . PHP_EOL;
		$output .= '
		flowplayer("player", "flash/flowplayer-3.2.7.swf", {
			clip: {
				title: "Video ' . $this->_video_id . '",
				autoPlay: true,
				autoBuffering: true,
				playlist: [
					{
						title: "Advertisement",
						url: "ads/preroll' . $this->_video_id . '.flv",
						position: 0
					}
				]
			}
		}).playlist("#playlist");' . PHP_EOL;
		$output .= '</script>' . PHP_EOL;
		$output .= '</body>' . PHP_EOL;
		$output .= '</html>' . PHP_EOL;
		return $output;
	}
}

$flowPlayer = new plgContentFlowplayer();
echo $flowPlayer->load();